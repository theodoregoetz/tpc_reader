// Boost.Test
#define BOOST_TEST_MAIN
#include <boost/test/unit_test.hpp>

//____________________________________________________________________________//

BOOST_AUTO_TEST_CASE( test_something )
{
    BOOST_CHECK_EQUAL( 1, 1 );
}

//____________________________________________________________________________//

// EOF
